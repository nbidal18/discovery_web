document.addEventListener('DOMContentLoaded', function() {
    //changes color of background hwne clicking the button
    document.getElementById('colorButton').addEventListener('click', function() {
        const randomColor = '#' + Math.floor(Math.random() * 16777215).toString(16);
        document.body.style.backgroundColor = randomColor;
    });
});
